-- Velour shop setup. Paste this whole file into Supabase > SQL Editor > Run.
create extension if not exists pgcrypto;
create table if not exists products(
  id uuid primary key default gen_random_uuid(),
  category text not null, category_order int not null default 0,
  grp text not null default '', name text not null, description text not null default '',
  price int not null default 0, emoji text not null default '🥤', image_url text not null default '',
  sold_out boolean not null default false, sort int not null default 0,
  created_at timestamptz not null default now());
create table if not exists settings(key text primary key, value jsonb not null);
alter table products enable row level security;
alter table settings enable row level security;
create policy "public read products" on products for select using (true);
create policy "public read settings" on settings for select using (true);
create policy "admin write products" on products for all to authenticated using (true) with check (true);
create policy "admin write settings" on settings for all to authenticated using (true) with check (true);
insert into storage.buckets(id,name,public) values('product-images','product-images',true) on conflict (id) do nothing;
create policy "public read images" on storage.objects for select using (bucket_id='product-images');
create policy "admin add images" on storage.objects for insert to authenticated with check (bucket_id='product-images');
create policy "admin change images" on storage.objects for update to authenticated using (bucket_id='product-images');
create policy "admin remove images" on storage.objects for delete to authenticated using (bucket_id='product-images');
-- Starting menu
insert into products(category,category_order,grp,name,description,price,emoji,image_url,sold_out,sort) values
('Milkshakes',0,'Classic single flavours · ₦6,000','Vanilla','Classic single flavour',6000,'🥤','img/circ2.jpg',false,0),
('Milkshakes',0,'Classic single flavours · ₦6,000','Banana','Classic single flavour',6000,'🥤','img/s3.jpg',false,1),
('Milkshakes',0,'Classic single flavours · ₦6,000','Chocolate','Classic single flavour',6000,'🥤','img/s4.jpg',false,2),
('Milkshakes',0,'Classic single flavours · ₦6,000','Coffee','Classic single flavour',6000,'🥤','img/coffee.jpg',false,3),
('Milkshakes',0,'Double flavours · ₦8,000','Vanilla x Coffee','Double flavour',8000,'☕','',false,4),
('Milkshakes',0,'Double flavours · ₦8,000','Coffee x Chocolate','Double flavour',8000,'🥤','img/s5.jpg',false,5),
('Milkshakes',0,'Double flavours · ₦8,000','Banana x Vanilla','Double flavour',8000,'🥤','img/s2.jpg',false,6),
('Milkshakes',0,'Double flavours · ₦8,000','Oreos/Micvites x Vanilla','Double flavour',8000,'🥤','img/oreo.jpg',false,7),
('Milkshakes',0,'Premium single flavours · ₦6,500','Strawberry','Premium single flavour',6500,'🥤','img/straw.jpg',false,8),
('Milkshakes',0,'Premium single flavours · ₦6,500','Oreos/Micvites','Premium single flavour',6500,'🥤','img/circ1.jpg',false,9),
('Milkshakes',0,'Premium single flavours · ₦6,500','Peanut Butter','Premium single flavour',6500,'🥜','',false,10),
('Smoothies',1,'Fruit combo · ₦4,000 each (toppings +₦500)','Pineapple × Banana','Fresh fruit combo',4000,'🥤','img/s12.jpg',false,0),
('Smoothies',1,'Fruit combo · ₦4,000 each (toppings +₦500)','Orange × Pineapple','Fresh fruit combo',4000,'🥤','img/s11.jpg',false,1),
('Smoothies',1,'Fruit combo · ₦4,000 each (toppings +₦500)','Apple × Banana','Fresh fruit combo',4000,'🥤','img/s13.jpg',false,2),
('Smoothies',1,'Fruit combo · ₦4,000 each (toppings +₦500)','Watermelon × Pineapple','Fresh fruit combo',4000,'🥤','img/s10.jpg',false,3),
('Smoothies',1,'Fruit combo · ₦4,000 each (toppings +₦500)','Pineapple × Watermelon × Banana','Fresh fruit combo',4000,'🥤','img/s10.jpg',false,4),
('Smoothies',1,'Fruit combo · ₦4,000 each (toppings +₦500)','Orange × Watermelon × Pineapple','Fresh fruit combo',4000,'🥤','img/s11.jpg',false,5),
('Smoothies',1,'Premium and detox · ₦6,000 each (toppings +₦500)','Beetroot Bliss','Beetroot + Pineapple + Orange',6000,'🥤','img/s9.jpg',false,6),
('Smoothies',1,'Premium and detox · ₦6,000 each (toppings +₦500)','Tropical Velour','Pineapple + Watermelon + Banana',6000,'🥤','img/s8.jpg',false,7),
('Smoothies',1,'Premium and detox · ₦6,000 each (toppings +₦500)','Green Glow','Pineapple + Cucumber + Ginger',6000,'🥤','img/s7.jpg',false,8),
('Smoothies',1,'Premium and detox · ₦6,000 each (toppings +₦500)','Carrot Glow','Carrot + Pineapple + Orange',6000,'🥤','img/s6.jpg',false,9),
('Smoothies',1,'Premium and detox · ₦6,000 each (toppings +₦500)','Apple Beet','Apple + Beetroot + Orange',6000,'🥤','img/s1.jpg',false,10);
insert into settings(key,value) values('shop','{"whatsapp":"2349070281280","delivery_fee":1500,"topping_price":500,"toppings":["Chia Seeds","Granola","Peanut Butter"],"topping_categories":["Smoothies"]}') on conflict (key) do nothing;
