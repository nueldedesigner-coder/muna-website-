# Velour shop: setup guide

Two sites in one folder:
- `/` is the customer shop. It reads the menu from Supabase.
- `/admin/` is the admin site. The client signs in with their own email and password and edits products, photos, prices, sold-out status, categories and settings. Changes show on the shop straight away, with no publishing step.

## 1. Create the Supabase project (free)
1. Go to supabase.com, create a project and wait until it is ready.
2. Open **SQL Editor**, paste all of `supabase-setup.sql` and press **Run**. This creates the tables, the security rules, the photo storage and the starting menu.
3. Open **Authentication > Providers > Email** and turn **off** "Allow new users to sign up". This stops strangers creating accounts.
4. Open **Authentication > Users > Add user > Create new user**. Enter the client's email and a password and tick "Auto Confirm User". This is the admin login.
5. Open **Project Settings > API** and copy the **Project URL** and the **anon public** key.

## 2. Add your keys
Open `config.js` and paste the Project URL and anon key. The anon key is safe to be public because the security rules only let signed-in users change anything.

## 3. Put it online (Netlify or Vercel, both free)
The folder that contains `index.html` must be the root of the site.
- **Netlify:** go to app.netlify.com/drop and drag the `velour-site` folder onto the page.
- **Vercel:** create a project from the `velour-site` folder (upload it to GitHub, or run `vercel` inside the folder). Set Framework Preset to **Other** and leave Build Command and Output Directory empty. If your repository has `velour-site` as a subfolder, set **Root Directory** to `velour-site`.
- The shop is at your link and the admin is at `your-link/admin/`.

## Notes
- The starting menu uses the photos in the `img` folder. Photos the client uploads later go to Supabase storage.
- The three banner slides at the top of the shop are fixed in `index.html`.
- The WhatsApp number can be changed in the admin under Settings.
